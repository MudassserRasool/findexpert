import React from 'react'
import TabsForSections from './components/TabsForSections/TabsForSections.jsx'

const App = () => {
  return (
    <div>
      <TabsForSections/>
    </div>
  )
}

export default App